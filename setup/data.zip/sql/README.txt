# Resources

*   `gen-survey-database.sql`: re-generate survey database used in examples.
*   `sqlitemagic.py`: IPython Notebook plugin to support SQLite interaction.

# Notes

* Run 'sqlite3 survey.db < gen-survey-database.sql' to re-create survey database before loading notebooks.
