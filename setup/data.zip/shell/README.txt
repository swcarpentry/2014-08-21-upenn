# Resources

*   `filesystem`: filesystem used in "Files and Directories"
*   `creatures`: DNA data used in "Loops"
*   `finding`: data using in "Finding Things"
*   `molecules`: PDB files used in "Pipes and Filters"
*   `scripting`: files and directories used in "Shell Scripts"
